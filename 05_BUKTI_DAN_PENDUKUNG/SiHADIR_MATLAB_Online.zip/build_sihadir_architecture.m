function build_sihadir_architecture(outFile)
%BUILD_SIHADIR_ARCHITECTURE  Build the SiHADIR System Composer model.
%
%   build_sihadir_architecture() creates SiHADIR_Architecture.slx in the
%   current folder from SIHADIR_ARCH_SPEC.
%
%   build_sihadir_architecture(outFile) writes the model to outFile.
%
%   Requires: Simulink + System Composer (R2024b or newer).
%   The function is idempotent: an existing model is closed and rebuilt.
%
%   Structure produced
%     SiHADIR
%       S1 Edge Terminal      -> C1.1 .. C1.11
%       S2 Backend Services   -> C2.1 .. C2.8
%       S3 Integration        -> C3.1 .. C3.4
%       S4 Data Management    -> C4.1 .. C4.4
%       S5 User Interfaces    -> C5.1 .. C5.3
%       S6 Identity & Privacy -> C6.1 .. C6.3
%     + interface dictionary  (16 interfaces)
%     + 22 links, cross-subsystem links exposed through subsystem ports
%
%   See also SIHADIR_ARCH_SPEC, VERIFY_ARCHITECTURE_SPEC.

if nargin < 1 || isempty(outFile)
    outFile = 'SiHADIR_Architecture.slx';
end
[outDir, modelName] = fileparts(outFile);
if isempty(outDir)
    outDir = pwd;
end

% Nama fitur lisensi berbeda antar rilis: R2026b memakai 'System_Composer'.
licensed = license('test', 'Simulink_System_Composer') == 1 ...
        || license('test', 'System_Composer') == 1;
assert(licensed, ...
    ['System Composer tidak berlisensi pada instalasi MATLAB ini.\n' ...
     'Jalankan skrip ini pada MATLAB dengan lisensi System Composer ' ...
     '(mis. MATLAB Online kampus), atau gunakan verify_architecture_spec ' ...
     'untuk memeriksa definisi arsitektur tanpa membangun model.']);

spec = sihadir_arch_spec();
fprintf('Membangun model %s ...\n', modelName);

% tutup model lama bila ada
if bdIsLoaded(modelName)
    close_system(modelName, 0);
end
if exist(fullfile(outDir, [modelName '.slx']), 'file')
    delete(fullfile(outDir, [modelName '.slx']));
end

model = systemcomposer.createModel(modelName, systemcomposer.ModelType.Architecture);
arch  = model.Architecture;

% ------------------------------------------------------------ interfaces
dictPath = fullfile(outDir, [modelName '_Interfaces.sldd']);
if exist(dictPath, 'file')
    dict = systemcomposer.openDictionary(dictPath);
else
    dict = systemcomposer.createDictionary(dictPath);
end
try
    linkDictionary(model, dict);
catch
    try
        model.linkDictionary(dict);
    catch err
        warning('sihadir:dict', 'Gagal menautkan dictionary: %s', err.message);
    end
end

ifMap = containers.Map('KeyType', 'char', 'ValueType', 'any');
nIf = 0;
for k = 1:numel(spec.interfaces)
    id = spec.interfaces(k).id;
    try
        iface = addInterface(dict, id);
        els = spec.interfaces(k).elements;
        for e = 1:numel(els)
            parts = split(string(els{e}), ':');
            try
                iface.addElement(char(parts(1)), char(parts(2)));
            catch
                % elemen duplikat saat model dibangun ulang: abaikan
            end
        end
        ifMap(id) = iface;
        nIf = nIf + 1;
    catch
        % interface sudah ada: ambil dari dictionary bila mungkin
        try
            ifMap(id) = dict.getInterface(id);
        catch
        end
    end
end
fprintf('  interface : %d\n', nIf);

% ------------------------------------------------------------ subsystems
subComp = containers.Map('KeyType', 'char', 'ValueType', 'any');
for k = 1:numel(spec.subsystems)
    s = spec.subsystems(k);
    c = addComponent(arch, sprintf('%s %s', s.id, s.name));
    subComp(s.id) = c;
end

% ------------------------------------------------------------ components
compHandle = containers.Map('KeyType', 'char', 'ValueType', 'any');
for k = 1:numel(spec.components)
    c = spec.components(k);
    parent = subComp(c.subsystem);
    h = addComponent(parent.Architecture, sprintf('%s %s', c.id, c.name));
    compHandle(c.id) = h;
end
fprintf('  komponen  : %d\n', compHandle.Count);

% ------------------------------------------------------------ ports
portHandle = containers.Map('KeyType', 'char', 'ValueType', 'any');
for k = 1:numel(spec.ports)
    p = spec.ports(k);
    h = compHandle(p.comp);
    ph = addPort(h, p.name);
    setPortDirection(ph, p.dir);
    if ~strcmp(p.interface, 'internal')
        if isKey(ifMap, p.interface)
            setPortInterface(ph, ifMap(p.interface), p.interface);
        end
    end
    portHandle([p.comp '/' p.name]) = ph;
end
fprintf('  port      : %d\n', portHandle.Count);

% ------------------------------------------------------------ links
nLink = 0;
for k = 1:numel(spec.links)
    l = spec.links(k);
    srcH = portHandle([l.src '/' l.srcPort]);
    dstH = portHandle([l.dst '/' l.dstPort]);
    subS = compSubsystem(spec, l.src);
    subD = compSubsystem(spec, l.dst);

    if strcmp(subS, subD)
        connect(srcH, dstH);
    else
        % ekspos lewat port subsistem
        sName = matlab.lang.makeValidName(sprintf('%s_%s', l.src, l.srcPort));
        dName = matlab.lang.makeValidName(sprintf('%s_%s', l.dst, l.dstPort));
        spSrc = addPort(subComp(subS), sName);
        spDst = addPort(subComp(subD), dName);
        connect(srcH, spSrc);
        connect(spDst, dstH);
        connect(spSrc, spDst);
    end
    nLink = nLink + 1;
end
fprintf('  link      : %d\n', nLink);

% ------------------------------------------------------------ save
save(model);
close(model);
fprintf('Selesai: %s\n', fullfile(outDir, [modelName '.slx']));
end

% ======================================================================
function setPortDirection(port, dir)
%SETPORTDIRECTION  Apply 'in'/'out' with a fallback over accepted spellings.
if isempty(dir)
    return
end
if lower(dir(1)) == 'i'
    candidates = {'Input', 'In', 'input', 'in'};
else
    candidates = {'Output', 'Out', 'output', 'out'};
end
for k = 1:numel(candidates)
    try
        port.Direction = candidates{k};
        return
    catch
        % coba ejaan berikutnya
    end
end
warning('sihadir:portDirection', 'Arah port %s tidak dapat diset ke %s.', ...
    string(port.Name), dir);
end

% ======================================================================
function setPortInterface(port, ifaceObj, ifaceName)
%SETPORTINTERFACE  Attach a data interface, tolerating API differences.
try
    setInterface(port, ifaceObj);
    return
catch
    % lanjut ke cara berikutnya
end
try
    port.Interface = ifaceObj;
    return
catch
    % lanjut
end
try
    port.InterfaceName = ifaceName;
catch err
    warning('sihadir:portInterface', 'Interface %s gagal dipasang pada port %s: %s', ...
        ifaceName, string(port.Name), err.message);
end
end

% ======================================================================
function s = compSubsystem(spec, compId)
idx = find(strcmp({spec.components.id}, compId), 1);
if isempty(idx)
    error('sihadir:unknownComponent', 'Komponen tidak dikenal: %s', compId);
end
s = spec.components(idx).subsystem;
end
